﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DatabaseTrybutitsEntityFramework
{
    public partial class MainWindow : Window
    {
        DataClasses1DataContext dc = new DataClasses1DataContext(Properties.Settings.Default.Data1ConnectionString);
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(usernameBox.Text) || !string.IsNullOrWhiteSpace(passwordBox.Password))
            {
                UserData user = dc.UserData.FirstOrDefault(x => x.UserName == usernameBox.Text);
                if ((sender as Button).Name.Equals("loginButton"))
                {
                    if (user != null)
                    {
                        if (user.UserPass.Equals(passwordBox.Password))
                        {
                            signinout.Foreground = Brushes.LightGreen;
                            signinout.Content = "Login succesful";
                        }
                        else
                        {
                            signinout.Foreground = Brushes.Red;
                            signinout.Content = "Invalid Password";
                        }
                    }
                    else
                    {
                        signinout.Foreground = Brushes.Red;
                        signinout.Content = "Invalid Username";
                    }
                }
                else if ((sender as Button).Name.Equals("registerButton"))
                {
                    if (user == null)
                    {
                        if (passwordBox.Password.Length > 7 && passwordBox.Password.Length < 50 && (!usernameBox.Text.Contains("'") || !passwordBox.Password.Contains("'")))
                        {
                            UserData newuser = new UserData
                            {
                                UserID = dc.UserData.Count(),
                                UserName = usernameBox.Text,
                                UserPass = passwordBox.Password

                            };
                            try
                            {
                                dc.UserData.InsertOnSubmit(newuser);
                                dc.SubmitChanges();
                                signinout.Foreground = Brushes.LightGreen;
                                signinout.Content = "Registration succesful!";
                            }
                            catch (Exception exc)
                            {
                                signinout.Foreground = Brushes.Red;
                                signinout.Content = "ERROR: \n" + exc;
                                loginButton.IsEnabled = false;
                                registerButton.IsEnabled = false;
                            }
                        }
                        else
                        {
                            signinout.Foreground = Brushes.Red;
                            signinout.Content = "Password has to have at least 8 characters";
                        }
                    }
                    else
                    {
                        signinout.Foreground = Brushes.Red;
                        signinout.Content = "Account with this name already exists";
                    }
                }
            }
            else
            {
                signinout.Foreground = Brushes.Red;
                signinout.Content = "Input fields cannot be empty";
            }
        }
    }
    public class Book
    {
        public string name;
    }
}
